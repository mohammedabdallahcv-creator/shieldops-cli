"""ShieldOps CLI commands."""
